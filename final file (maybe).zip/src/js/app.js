App = {
  webProvider: null,
  contracts: {},
  account: '0x0',
  web3: null,

  init: async function () {
    if (window.ethereum) {
      App.webProvider = window.ethereum;
      try {
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        const accounts = await App.webProvider.request({ method: 'eth_accounts' });
        App.account = accounts[0];
        document.getElementById('accountAddress').innerText = `Current Account: ${App.account}`;
        App.web3 = new Web3(App.webProvider);
        App.listenForAccountChanges();
        await App.initContract();
        await App.checkUserRole();
      } catch (error) {
        console.error("MetaMask access error:", error);
        document.getElementById('accountAddress').innerText = "MetaMask connection failed.";
      }
    } else {
      alert('Please install MetaMask!');
      document.getElementById('accountAddress').innerText = "MetaMask not found.";
    }
  },

  initContract: async function () {
    const res = await fetch('MissingPersonsManagement.json');
    const contractData = await res.json();

    App.contracts.MissingPersonsManagement = TruffleContract(contractData);
    App.contracts.MissingPersonsManagement.setProvider(App.webProvider);
    App.instance = await App.contracts.MissingPersonsManagement.deployed();

    App.bindEvents();
  },

  bindEvents: function () {
    document.getElementById('registrationForm').addEventListener('submit', App.handleRegisterUser);
  },

  handleRegisterUser: async function (e) {
    e.preventDefault();

    const role = parseInt(document.getElementById("role").value);
    const nid = document.getElementById("nid").value;
    const name = document.getElementById("name").value;

    try {
      await App.instance.registerUser(nid, name, role, { from: App.account });

      document.getElementById("registerMessage").className = "alert alert-success";
      document.getElementById("registerMessage").innerText = "Registration successful!";
      document.getElementById("registrationForm").reset();

      // Reload to re-check role and hide form
      setTimeout(() => window.location.reload(), 2000);
    } catch (error) {
      console.error("Registration error:", error);
      document.getElementById("registerMessage").className = "alert alert-danger";
      document.getElementById("registerMessage").innerText = "Registration failed. Check console.";
    }
  },

  checkUserRole: async function () {
    try {
      const roleId = await App.instance.getMyRoleUint({ from: App.account });
      const roleName = roleId == 1 ? "Admin" : roleId == 2 ? "Reporter" : roleId == 3 ? "Investigator" : null;

      if (roleName) {
        document.getElementById('registrationForm').style.display = 'none';
        const roleDisplay = document.createElement('div');
        roleDisplay.className = 'alert alert-success mt-4';
        roleDisplay.innerHTML = `<strong>You are registered as:</strong> ${roleName}`;
        document.querySelector('.card').appendChild(roleDisplay);
      }
    } catch (err) {
      console.log("User not registered yet.");
    }
  },

  listenForAccountChanges: function () {
    window.ethereum.on('accountsChanged', function (accounts) {
      if (accounts.length > 0) {
        App.account = accounts[0];
        document.getElementById('accountAddress').innerText = `Current Account: ${App.account}`;
        window.location.reload(); // Re-initialize role check
      } else {
        document.getElementById('accountAddress').innerText = 'No Account Connected';
      }
    });
  }
};

window.addEventListener('load', function () {
  App.init();
});
